//
//  dashboadViewController.m
//  NSUSER DEFAULT
//
//  Created by Student 6 on 10/04/17.
//  Copyright © 2017 felix. All rights reserved.
//

#import "dashboadViewController.h"
#import "AppDelegate.h"
@interface dashboadViewController ()

@end

@implementation dashboadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"dashboard";
    NSUserDefaults *df=[NSUserDefaults standardUserDefaults];
    _txtlbl.text=[df valueForKey:@"txtmail"];
    _lblpass.text=[df valueForKey:@"txtpass"];
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)LogOutAct:(id)sender {
    NSUserDefaults *df=[NSUserDefaults standardUserDefaults];
    [df setValue:@"NO" forKey:@"Login"];
    [df synchronize];
    
    AppDelegate *userdel=(AppDelegate *)[UIApplication sharedApplication].delegate;
    [userdel LoginLogout];
    

    
}
@end
