//
//  ViewController.m
//  NSUSER DEFAULT
//
//  Created by Student 6 on 10/04/17.
//  Copyright © 2017 felix. All rights reserved.
//

#import "ViewController.h"
#import "dashboadViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //self.title=@"Login";
    
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"firsttosec"]) {
        NSUserDefaults *df=[NSUserDefaults standardUserDefaults];
        [df setObject:@"YES" forKey:@"Login"];
        [df setObject:_txtmail.text forKey:@"txtmail"];
        [df setObject:_txtpassword.text forKey:@"txtpass"];
        
        [df synchronize];
        
        
                            
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
